import xml.dom.minidom

candidate = []
def get_tagname():
    file=xml.dom.minidom.parse("candidates_all.xml")
    for node in file.getElementsByTagName("CANDIDATE"):
        parent = node.parentNode
        p_parent = parent.parentNode
        if (parent.tagName == "PRESIDENT"):
            office = parent.tagName
            party_node = node.getElementsByTagName("PARTY")
            party = party_node[0].childNodes[0].nodeValue
            fname_node = node.getElementsByTagName("FNAME")
            fname = fname_node[0].childNodes[0].nodeValue
            mname_node = node.getElementsByTagName("MNAME")
            mname = mname_node[0].childNodes[0].nodeValue
            lname_node = node.getElementsByTagName("LNAME")
            lname = lname_node[0].childNodes[0].nodeValue
            address_node = node.getElementsByTagName("ADDRESS")
            address = address_node[0].childNodes[0].nodeValue
            zip_node = node.getElementsByTagName("ZIP")
            zip = zip_node[0].childNodes[0].nodeValue
            print("Office:" + office + " Party:" + party + " Fname:" + fname + " Mname:" + mname + " Lname:" + lname + " Address:" + address + " Zip:" + zip)
            candidate.append(fname + ',' + mname + ',' + lname + ',' + party + ',' + address + ',' + zip + ',' + office)
        elif(p_parent.tagName == "MAYOR" or "GOVERNOR" or "USSENATE" or "STATEHOUSE"):
            office = p_parent.tagName
            district = parent.getAttribute("VALUE")
            party_node = node.getElementsByTagName("PARTY")
            party = party_node[0].childNodes[0].nodeValue
            fname_node = node.getElementsByTagName("FNAME")
            fname = fname_node[0].childNodes[0].nodeValue
            mname_node = node.getElementsByTagName("MNAME")
            mname = mname_node[0].childNodes[0].nodeValue
            lname_node = node.getElementsByTagName("LNAME")
            lname = lname_node[0].childNodes[0].nodeValue
            address_node = node.getElementsByTagName("ADDRESS")
            address = address_node[0].childNodes[0].nodeValue
            zip_node = node.getElementsByTagName("ZIP")
            zip = zip_node[0].childNodes[0].nodeValue
            print("Office:" + office + " district:" + district + " Party:" + party + " Fname:" + fname + " Mname:" + mname + " Lname:" + lname + " Address:" + address + " Zip:" + zip)
            candidate.append(fname+','+mname+','+lname+','+party+','+address+','+zip+','+office+','+district)
        elif(p_parent.tagName == "DISTRICTATTORNEY"):
            office = p_parent.tagName
            district = parent.getAttribute("VALUE")
            party_node = node.getElementsByTagName("PARTY")
            party = party_node[0].childNodes[0].nodeValue
            fname_node = node.getElementsByTagName("FNAME")
            fname = fname_node[0].childNodes[0].nodeValue
            mname_node = node.getElementsByTagName("MNAME")
            mname = mname_node[0].childNodes[0].nodeValue
            lname_node = node.getElementsByTagName("LNAME")
            lname = lname_node[0].childNodes[0].nodeValue
            address_node = node.getElementsByTagName("ADDRESS")
            address = address_node[0].childNodes[0].nodeValue
            zip_node = node.getElementsByTagName("ZIP")
            zip = zip_node[0].childNodes[0].nodeValue
            print("Office:" + office + " district:" + district + " Party:" + party + " Fname:" + fname + " Mname:" + mname + " Lname:" + lname + " Address:" + address + " Zip:" + zip)
            candidate.append(fname + ',' + mname + ',' + lname + ',' + party + ',' + address + ',' + zip + ',' + office + ',' + district)



if(__name__ == "__main__"):
    get_tagname()
    with open('candidates.txt', 'w') as f:
        for i in range(len(candidate)):
            print(candidate[i])
            f.write(candidate[i])
            f.write("\n")


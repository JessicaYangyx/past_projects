import xml.dom.minidom
import re

votes = []
def get_tagname():
    file=xml.dom.minidom.parse("votes.xml")
    for node in file.getElementsByTagName("VOTES"):
        parent = node.parentNode
        fname_node = parent.getElementsByTagName("FNAME")
        fname = fname_node[0].childNodes[0].nodeValue
        mname_node = parent.getElementsByTagName("MNAME")
        mname = mname_node[0].childNodes[0].nodeValue
        lname_node = parent.getElementsByTagName("LNAME")
        lname = lname_node[0].childNodes[0].nodeValue
        address_node = parent.getElementsByTagName("ADDRESS")
        address = address_node[0].childNodes[0].nodeValue
        zip_node = parent.getElementsByTagName("ZIP")
        zip = zip_node[0].childNodes[0].nodeValue
        party_node = parent.getElementsByTagName("PARTY")
        party = party_node[0].childNodes[0].nodeValue
        president_node = node.getElementsByTagName("PRESIDENT")
        if len(president_node) != 0:
            office = president_node[0].tagName
            president_value = president_node[0].childNodes[0].nodeValue
            president_fname = re.findall(r'[a-zA-Z]+~', president_value)
            president_mname = re.findall(r'~[a-zA-Z]+~', president_value)
            president_lname = re.findall(r'~[A-Z]+~', president_value)
            print("Fname:" + fname + " Mname:" + mname + " Lname:" + lname + " Address:" + address + " Zip:" + zip + " Party:" + party + " Office:" + office + " President_fname:" +
                  president_fname[0].strip('~') + " President_mname:" + president_mname[0].strip(
                        '~') + " President_lname:" + president_lname[0].strip('~'))
            votes.append(fname + ',' + mname + ',' + lname + ',' + address + ',' + zip + ',' + party + ',' + office + ',' + president_fname[0].strip('~') + ',' +
                         president_mname[0].strip('~') + ',' + president_lname[0].strip('~'))
        governor_node = node.getElementsByTagName("GOVERNOR")
        if len(governor_node) != 0:
            office = governor_node[0].tagName
            governor_value = governor_node[0].childNodes[0].nodeValue
            governor_fname = re.findall(r'[a-zA-Z]+~', governor_value)
            governor_mname = re.findall(r'~[a-zA-Z]+~', governor_value)
            governor_lname = re.findall(r'~[A-Z]+~', governor_value)
            print("Fname:" + fname + " Mname:" + mname + " Lname:" + lname + " Address:" + address + " Zip:" + zip + " Party:" + party + " Office:" + office + " Governor_fname:" +
                  governor_fname[0].strip('~') + " Governor_mname:" + governor_mname[0].strip(
                        '~') + " Governor_lname:" + governor_lname[0].strip('~'))
            votes.append(fname + ',' + mname + ',' + lname + ','  + address + ',' + zip + ',' + party + ',' + office + ',' + governor_fname[0].strip('~') + ',' +
                         governor_mname[0].strip('~') + ',' + governor_lname[0].strip('~'))
        senate_node = node.getElementsByTagName("SENATOR")
        if len(senate_node) != 0:
            office = senate_node[0].tagName
            senate_value = senate_node[0].childNodes[0].nodeValue
            senate_fname = re.findall(r'[a-zA-Z]+~', senate_value)
            senate_mname = re.findall(r'~[a-zA-Z]+~', senate_value)
            senate_lname = re.findall(r'~[A-Z]+~', senate_value)
            print("Fname:" + fname + " Mname:" + mname + " Lname:" + lname + " Address:" + address + " Zip:" + zip + " Party:" + party + " Office:" + office + " Senate_fname:" +
                  senate_fname[0].strip('~') + " Senate_mname:" + senate_mname[0].strip(
                        '~') + " Senate_lname:" + senate_lname[0].strip('~'))
            votes.append(fname + ',' + mname + ',' + lname + ',' + address + ',' + zip + ',' + party + ',' + office + ',' + senate_fname[0].strip('~') + ',' +
                         senate_mname[0].strip('~') + ',' + senate_lname[0].strip('~'))
        mayor_node = node.getElementsByTagName("MAYOR")
        if len(mayor_node) != 0:
            office = mayor_node[0].tagName
            mayor_value = mayor_node[0].childNodes[0].nodeValue
            mayor_fname = re.findall(r'[a-zA-Z]+~', mayor_value)
            mayor_mname = re.findall(r'~[a-zA-Z]+~', mayor_value)
            mayor_lname = re.findall(r'~[A-Z]+~', mayor_value)
            print("Fname:" + fname + " Mname:" + mname + " Lname:" + lname + " Address:" + address + " Zip:" + zip + " Party:" + party + " Office:" + office + " mayor_fname:" +
                  mayor_fname[0].strip('~') + " mayor_mname:" + mayor_mname[0].strip(
                        '~') + " mayor_lname:" + mayor_lname[0].strip('~'))
            votes.append(fname + ',' + mname + ',' + lname + ',' + address + ',' + zip + ',' + party + ',' + office + ',' + mayor_fname[0].strip('~') + ',' +
                         mayor_mname[0].strip('~') + ',' + mayor_lname[0].strip('~'))
        statehouse_node = node.getElementsByTagName("STATEHOUSE")
        if len(statehouse_node) != 0:
            office = statehouse_node[0].tagName
            statehouse_value = statehouse_node[0].childNodes[0].nodeValue
            statehouse_fname = re.findall(r'[a-zA-Z]+~', statehouse_value)
            statehouse_mname = re.findall(r'~[a-zA-Z]+~', statehouse_value)
            statehouse_lname = re.findall(r'~[A-Z]+~', statehouse_value)
            print("Fname:" + fname + " Mname:" + mname + " Lname:" + lname + " Address:" + address + " Zip:" + zip + " Party:" + party + " Office:" + office + " statehouse_fname:" +
                  statehouse_fname[0].strip('~') + " statehouse_mname:" + statehouse_mname[0].strip(
                        '~') + " statehouse_lname:" + statehouse_lname[0].strip('~'))
            votes.append(fname + ',' + mname + ',' + lname + ',' + address + ',' + zip + ',' + party + ',' + office + ',' + statehouse_fname[0].strip('~') + ',' +
                         statehouse_mname[0].strip('~') + ',' + statehouse_lname[0].strip('~'))
        districtattorney_node = node.getElementsByTagName("DISTRICTATTORNEY")
        if len(districtattorney_node) != 0:
            office = districtattorney_node[0].tagName
            districtattorney_value = districtattorney_node[0].childNodes[0].nodeValue
            districtattorney_fname = re.findall(r'[a-zA-Z]+~', districtattorney_value)
            districtattorney_mname = re.findall(r'~[a-zA-Z]+~', districtattorney_value)
            districtattorney_lname = re.findall(r'~[A-Z]+~', districtattorney_value)
            print(
                        "Fname:" + fname + " Mname:" + mname + " Lname:" + lname + " Address:" + address + " Zip:" + zip + " Party:" + party + " Office:" + office + " districtattorney_fname:" +
                        districtattorney_fname[0].strip('~') + " districtattorney_mname:" + districtattorney_mname[0].strip(
                    '~') + " districtattorney_lname:" + districtattorney_lname[0].strip('~'))
            votes.append(
                fname + ',' + mname + ',' + lname + ',' + address + ',' + zip + ',' + party + ',' + office + ',' +
                districtattorney_fname[0].strip('~') + ',' +
                districtattorney_mname[0].strip('~') + ',' + districtattorney_lname[0].strip('~'))



if(__name__ == "__main__"):
    get_tagname()
    with open('votes.txt', 'w') as f:
        for i in range(len(votes)):
            #print(votes[i])
            f.write(votes[i])
            f.write("\n")


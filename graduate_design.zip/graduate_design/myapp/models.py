# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.


class t_users(models.Model):
    # 用户编号
    id=models.AutoField(primary_key=True)
    # 用户姓名
    name=models.CharField(max_length=200)
    # 用户手机号
    phone=models.CharField(max_length=20)
    # 用户密码
    password=models.CharField(max_length=50)
    # 用户身份标识
    identity=models.IntegerField(default=0)         # 11:管理员，2:普通测试人员
    # 用户在职标识
    status=models.IntegerField(default=1)           # 1:在职，0:离职


class t_developers(models.Model):
    # 开发人员编号
    id=models.AutoField(primary_key=True)
    # 开发人员姓名
    name=models.CharField(max_length=200)
    # 开发人员手机号
    phone=models.CharField(max_length=20)
    # 开发人员密码
    password=models.CharField(max_length=50)
    # 开发在职标识
    status = models.IntegerField(default=1)         # 1:在职，0:离职


class t_products(models.Model):
    # 产品编号
    id=models.AutoField(primary_key=True)
    # 产品名称
    name=models.CharField(max_length=200)
    # 产品状态
    status=models.IntegerField(default=1)           # 1:使用中，0:已废弃


class t_projects(models.Model):
    # 项目编号
    id=models.AutoField(primary_key=True)
    # 项目名称
    name=models.CharField(max_length=200)
    #所属产品（外键，产品表主键）
    product=models.ForeignKey(t_products,on_delete=models.PROTECT)
    # 项目负责人（外键，用户表的主键）
    principal=models.ForeignKey(t_users, on_delete=models.PROTECT)
    # 项目状态（是否已完成）
    status=models.IntegerField(default=3)           # 1:进行中，2:已完成，3:未开始，0:关闭


class t_cases(models.Model):
    # 用例编号
    id=models.AutoField(primary_key=True)
    # 所属项目（外键，项目表的主键）
    project=models.ForeignKey(t_projects,on_delete=models.PROTECT)
    # 模块1
    module1=models.CharField(max_length=200)
    # 模块2
    module2=models.CharField(max_length=200)
    # 模块3
    module3=models.CharField(max_length=200)
    # 用例标题
    title=models.CharField(max_length=200)
    # 用例前置条件
    condition=models.CharField(max_length=500)
    # 用例步骤
    steps=models.CharField(max_length=500)
    # 用例预期结果
    predictions=models.CharField(max_length=500)
    # 用例优先级
    level=models.IntegerField(default=3)            # 1-2-3级优先级依次下降
    # 作者（外键，用户表的主键）
    author=models.ForeignKey(t_users,on_delete=models.PROTECT)



class t_bugs(models.Model):
    # bug编号
    id=models.AutoField(primary_key=True)
    # 项目编号（外键，项目表的主键）
    proj_no=models.ForeignKey(t_projects, on_delete=models.PROTECT)
    # 用例编号（外键，用例表的主键）
    case_no=models.ForeignKey(t_cases, on_delete=models.PROTECT)
    # 责任人id（外键，开发人员表的主键）
    responsible=models.ForeignKey(t_developers, on_delete=models.PROTECT)
    #状态
    status=models.IntegerField(default=1)           #0:已关闭，1:未解决，2:已解决


class t_projcases(models.Model):
    # 项目用例编号
    id=models.AutoField(primary_key=True)
    # 项目编号（外键，项目表的主键）
    proj_no=models.ForeignKey(t_projects, on_delete=models.PROTECT)
    # 用例编号（外键，用例表的主键）
    case_no=models.ForeignKey(t_cases, on_delete=models.CASCADE)
    # 用例执行结果
    status=models.IntegerField(default=0)           # 0未执行，1通过，2失败，3阻塞，4忽略
    # bug编号（没有bug默认为0，有的话关联bug表的id）
    bug_no_id=models.IntegerField(default=0)
    # 用例执行时间
    time=models.DateTimeField(auto_now=True)
    # 用例执行人（外键，用户表的主键）
    person=models.ForeignKey(t_users, on_delete=models.PROTECT)
    # 用例执行备注 （结果为失败、阻塞时必填）
    remark=models.CharField(max_length=500,default="")



# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.http import HttpResponse
from django.http import HttpResponseRedirect

from django.shortcuts import render
from myapp import models

from django.template import RequestContext

# Create your views here.

def hello(request):
    #return HttpResponse("Hello world!")
    context={}
    context['hello']='Hello World!'
    return render(request,'hello.html',context)

def login(request):
    return render(request,'login.html')

def page404(request):
    return render(request,'404.html')

def page505(request):
    return render(request,'505.html')

def barcharts(request):
    return render(request,'barcharts.html')

def buttons(request):
    return render(request,'buttons.html')

def calender(request):
    return render(request,'calender.html')

# def datatables_admin(request):
#     return render(request, 'datatables_admin.html')
#
# def datatables_user(request):
#     return render(request,'datatables_user.html')

# def cases_management(request):
#     return render(request, 'cases_management_admin.html')

# def test_exe(request):
#     return render(request, 'test_exe_admin.html')

# def employee(request):
#     return render(request,'employee.html')

# def project_management(request):
#     return render(request, 'project_management_admin.html')

def bug_management(request):
    return render(request,'bug_management.html')


'''用户登录'''
def user_login(request):
    if request.POST:
        user_phone = request.POST["phone"]
        user_password = request.POST["password"]
        print request.POST
        #获取表单数据与数据库进行比较
        user=models.t_users.objects.filter(phone__exact=user_phone, password__exact= user_password, status__exact=1).first()
        #判断该用户是否已离职
        isRetire=models.t_users.objects.filter(phone=user_phone,status=0)
        #判断是否是管理员身份
        isAdmin=models.t_users.objects.filter(phone=user_phone,identity=11)
        # 查询全部人员信息
        user_list=models.t_users.objects.all()
        for line in user_list:
            print "id=%d, name=%s, phone=%s, password=%s, identity=%d, status=%d"%(line.id,line.name,line.phone,line.password,line.identity,line.status)
        # print "user_list%s="% user_list
        # print user
        if isRetire:
            context = {
                'context': u"该账户不存在！"
            }
            return render(request, "login.html", context=context)

        elif user:
            if isAdmin:
                context = {
                    'context': u"登录成功",
                    'user': user_phone,
                    'user_list': user_list,
                }
                return HttpResponseRedirect("/test_exe_admin")
            else:
                context={
                    'context':u"登录成功",
                    'user':user_phone,
                    'user_list':user_list,
                }
                # return render(request,'datatables_admin.html',context=context)
                return HttpResponseRedirect("/test_exe_user")
        else:
            context={
                'context':u"账号或密码错误，登录失败"
            }
            return render(request,"login.html",context=context)
    return render(request,"login.html")


def register(request):
    # return render(request,"register.html")
    if request.POST:
        user_name=request.POST["name"]
        user_phone=request.POST["phone"]
        user_password=request.POST["password"]
        user_identity=request.POST.get('identity')
        same_phone=models.t_users.objects.filter(name=user_name)
        if same_phone:
            message={
                'context':u'该用户已存在，无需注册！'
            }
            print message
            return render(request,'register.html',context=message)
            # return HttpResponseRedirect("/register")
        new_user=models.t_users.objects.create()
        new_user.name=user_name
        new_user.phone=user_phone
        new_user.password=user_password
        new_user.identity=user_identity
        new_user.save()
        message={'context':u'注册成功！'}
        print message
        # return render(request,'login.html',locals())
        return HttpResponseRedirect("/login")
    return render(request,'register.html')
    # return HttpResponseRedirect("/register")


def reset(request):
    if request.POST:
        user_phone=request.POST.get('phone')
        user_password=request.POST.get('password')
        user_new_password=request.POST.get('repassword')
        if user_password!=user_new_password:
            context={
                'context':u'两次输入密码不一致，请重新输入！'
            }
            print context
            return render(request,'reset.html',context=context)
        models.t_users.objects.filter(phone=user_phone).update(password=user_new_password)
        context={
            'context':u'密码修改成功！'
        }
        print context
        return HttpResponseRedirect("/login")
    return render(request,'reset.html')


def getProjects(request):
    projects=models.t_projects.objects.all()
    print(projects)
    return projects


def getUsers(request):
    users=models.t_users.objects.all()
    print(users)
    return users


def getProducts(request):
    products=models.t_products.objects.all()
    print(products)
    return products


'''管理员主页'''
def datatables_admin(request):
    projects=getProjects(request)
    users=getUsers(request)
    products=getProducts(request)
    return render(request,'datatables_admin.html',{'projects':projects,'users':users,'products':products})


'''用户主页'''
def datatables_user(request):
    projects = getProjects(request)
    users = getUsers(request)
    products = getProducts(request)
    return render(request, 'datatables_user.html', {'projects':projects,'users':users,'products':products})


def getCases(request):
    cases=models.t_cases.objects.all()
    print(cases)
    return cases


'''管理员用例管理页面'''
def cases_management_admin(request):
    cases=getCases(request)
    users=getUsers(request)
    projects=getProjects(request)
    return render(request,'cases_management_admin.html',{'cases':cases,'users':users,'projects':projects})


'''用户用例管理页面'''
def cases_management_user(request):
    cases=getCases(request)
    users=getUsers(request)
    projects=getProjects(request)
    return render(request,'cases_management_user.html',{'cases':cases,'users':users,'projects':projects})


'''管理员在用例管理页删除用例'''
def caseDeletion_admin(request):
    id=request.GET.get("id")
    models.t_cases.objects.filter(id=id).delete()
    return HttpResponseRedirect("/cases_management_admin")


'''员工在用例管理页删除用例'''
def caseDeletion_user(request):
    id=request.GET.get("id")
    models.t_cases.objects.filter(id=id).delete()
    return HttpResponseRedirect("/cases_management_user")


'''员工管理页面'''
def employee(request):
    users=getUsers(request)
    return render(request,'employee.html',{'users':users})


'''设置离职员工'''
def del_employee(request):
    id=request.GET.get("id")
    # models.t_users.objects.filter(id=id).delete()
    isRetire=models.t_users.objects.filter(id=id,status=0)
    if isRetire:
        context = {
            'context': u"该员工已离职，无需设置离职状态！"
        }
        # employee(request)
        # return render(request, 'employee.html',context=context)
        return HttpResponseRedirect("/employee")
    else:
        models.t_users.objects.filter(id=id).update(status=0)
        context = {
            'context': u"离职状态设置成功！"
        }
        return HttpResponseRedirect("/employee")


'''进入修改员工信息界面'''
def getin_employee_editor(request):
    id=request.GET.get("id")
    emp = models.t_users.objects.filter(id=id).first()
    return render(request,'employee_editor.html',{'emp':emp})
    # return render(request,'employee_editor.html')


'''修改员工数据'''
def employee_change(request):
    id=request.GET.get("id")
    emp = models.t_users.objects.filter(id=id).first()
    if request.POST:
        # user_id=request.POST["id"]
        user_name=request.POST["name"]
        user_phone=request.POST["phone"]
        user_identity=request.POST.get('identity')
        user_status=request.POST.get('status')
        same_phone = models.t_users.objects.filter(phone=user_phone)
        if same_phone:
            message = {
                'context': u'该手机号已存在，请更改！'
            }
            print message
            return render(request, 'employee_editor.html',{'emp':emp,'context':message})
        models.t_users.objects.filter(id=id).update(name=user_name,phone=user_phone,identity=user_identity,status=user_status)
        message={'context':u'修改成功！'}
        print message
        # return render(request,'login.html',locals())
        return HttpResponseRedirect("/employee")
    # user_id=request.GET.get("id")
    return render(request,'employee_editor.html',{'emp':emp})


'''关闭项目'''
def close_project_admin(request):
    id=request.GET.get("id")
    models.t_projects.objects.filter(id=id).update(status=0)
    return HttpResponseRedirect("/project_management_admin")


def close_project_user(request):
    id=request.GET.get("id")
    models.t_projects.objects.filter(id=id).update(status=0)
    return HttpResponseRedirect("/project_management_user")


'''开始项目'''
def start_project_admin(request):
    id=request.GET.get("id")
    models.t_projects.objects.filter(id=id).update(status=1)
    return HttpResponseRedirect("/project_management_admin")


def start_project_user(request):
    id=request.GET.get("id")
    models.t_projects.objects.filter(id=id).update(status=1)
    return HttpResponseRedirect("/project_management_user")

'''项目管理界面-管理员'''
def project_management_admin(request):
    projects = getProjects(request)
    users = getUsers(request)
    products = getProducts(request)
    return render(request, 'project_management_admin.html', {'projects': projects, 'users': users, 'products': products})


'''项目管理界面-普通用户'''
def project_management_user(request):
    projects = getProjects(request)
    users = getUsers(request)
    products = getProducts(request)
    return render(request, 'project_management_user.html',{'projects': projects, 'users': users, 'products': products})


'''新建项目-管理员'''
def new_project_admin(request):
    users = getUsers(request)
    products = getProducts(request)
    if request.POST:
        proj_name=request.POST["name"]
        proj_principal=request.POST["principal"]
        proj_product=request.POST["product"]
        new_project=models.t_projects.objects.create(name=proj_name,principal_id=proj_principal,product_id=proj_product)
        new_project.save()
        message={'context':u'新增成功！'}
        print message
        # return render(request,'login.html',locals())
        return HttpResponseRedirect("/project_management_admin")
    return render(request,'new_project_admin.html',{'users':users,'products':products})


'''新建项目-普通用户'''
def new_project_user(request):
    users = getUsers(request)
    products = getProducts(request)
    if request.POST:
        proj_name=request.POST["name"]
        proj_principal=request.POST["principal"]
        proj_product=request.POST["product"]
        new_project=models.t_projects.objects.create(name=proj_name,principal_id=proj_principal,product_id=proj_product)
        new_project.save()
        message={'context':u'新增成功！'}
        print message
        # return render(request,'login.html',locals())
        return HttpResponseRedirect("/project_management_user")
    return render(request,'new_project_user.html',{'users':users,'products':products})


'''新建用例'''
def new_case_admin(request):
    users=getUsers(request)
    projects=getProjects(request)
    if request.POST:
        case_module1 = request.POST["module1"]
        case_module2 = request.POST["module2"]
        case_module3 = request.POST["module3"]
        case_title = request.POST["title"]
        case_condition=request.POST["condition"]
        case_steps=request.POST["steps"]
        case_predictions=request.POST["predictions"]
        case_level=request.POST["level"]
        case_author=request.POST["author"]
        case_project=request.POST["project"]
        new_case=models.t_cases.objects.create(module1=case_module1,module2=case_module2,module3=case_module3,title=case_title,condition=case_condition,steps=case_steps,predictions=case_predictions,level=case_level,author_id=case_author,project_id=case_project)
        new_case.save()
        find_new_case=models.t_cases.objects.filter(module1=case_module1,module2=case_module2,module3=case_module3,title=case_title,condition=case_condition,steps=case_steps,predictions=case_predictions,level=case_level,author_id=case_author,project_id=case_project).first()
        new_case_id=find_new_case.id
        new_exe=models.t_projcases.objects.create(case_no_id=new_case_id,proj_no_id=case_project)
        new_exe.save()
        message = {'context': u'新增成功！'}
        print message
        return HttpResponseRedirect("/cases_management_admin")
    return render(request,'new_case_admin.html',{'users':users,'projects':projects})



def new_case_user(request):
    users = getUsers(request)
    projects = getProjects(request)
    if request.POST:
        case_module1 = request.POST["module1"]
        case_module2 = request.POST["module2"]
        case_module3 = request.POST["module3"]
        case_title = request.POST["title"]
        case_condition = request.POST["condition"]
        case_steps = request.POST["steps"]
        case_predictions = request.POST["predictions"]
        case_level = request.POST["level"]
        case_author = request.POST["author"]
        case_project = request.POST["project"]
        new_case = models.t_cases.objects.create(module1=case_module1, module2=case_module2, module3=case_module3,
                                                 title=case_title, condition=case_condition, steps=case_steps,
                                                 predictions=case_predictions, level=case_level, author_id=case_author,
                                                 project_id=case_project)
        new_case.save()
        find_new_case = models.t_cases.objects.filter(module1=case_module1, module2=case_module2, module3=case_module3,
                                                      title=case_title, condition=case_condition, steps=case_steps,
                                                      predictions=case_predictions, level=case_level,
                                                      author_id=case_author, project_id=case_project).first()
        new_case_id = find_new_case.id
        new_exe = models.t_projcases.objects.create(case_no_id=new_case_id, proj_no_id=case_project)
        new_exe.save()
        message = {'context': u'新增成功！'}
        print message
        return HttpResponseRedirect("/cases_management_user")
    return render(request, 'new_case_user.html', {'users': users, 'projects': projects})



'''用例批量导入'''
# def import_cases(request):



'''模板下载'''
# def downloda_muban(request):


'''编辑用例-管理员'''
def edit_case_admin(request):
    id = request.GET.get("id")
    case = models.t_cases.objects.filter(id=id).first()
    users=getUsers(request)
    projects=getProjects(request)
    if request.POST:
        case_module1 = request.POST["module1"]
        case_module2 = request.POST["module2"]
        case_module3 = request.POST["module3"]
        case_title = request.POST["title"]
        case_condition = request.POST["condition"]
        case_steps = request.POST["steps"]
        case_predictions = request.POST["predictions"]
        case_level = request.POST["level"]
        case_author = request.POST["author"]
        case_project = request.POST["project"]
        models.t_cases.objects.filter(id=id).update(module1=case_module1, module2=case_module2, module3=case_module3,
                                                 title=case_title, condition=case_condition, steps=case_steps,
                                                 predictions=case_predictions, level=case_level, author_id=case_author,
                                                 project_id=case_project)
        message = {'context': u'修改成功！'}
        print message
        # return render(request,'login.html',locals())
        return HttpResponseRedirect("/cases_management_admin")
    # user_id=request.GET.get("id")
    return render(request, 'edit_case_admin.html', {'case': case,'users':users,'projects':projects})


'''编辑用例-普通用户'''
def edit_case_user(request):
    id = request.GET.get("id")
    case = models.t_cases.objects.filter(id=id).first()
    users=getUsers(request)
    projects=getProjects(request)
    if request.POST:
        case_module1 = request.POST["module1"]
        case_module2 = request.POST["module2"]
        case_module3 = request.POST["module3"]
        case_title = request.POST["title"]
        case_condition = request.POST["condition"]
        case_steps = request.POST["steps"]
        case_predictions = request.POST["predictions"]
        case_level = request.POST["level"]
        case_author = request.POST["author"]
        case_project = request.POST["project"]
        models.t_cases.objects.filter(id=id).update(module1=case_module1, module2=case_module2, module3=case_module3,
                                                 title=case_title, condition=case_condition, steps=case_steps,
                                                 predictions=case_predictions, level=case_level, author_id=case_author,
                                                 project_id=case_project)
        message = {'context': u'修改成功！'}
        print message
        # return render(request,'login.html',locals())
        return HttpResponseRedirect("/cases_management_user")
    # user_id=request.GET.get("id")
    return render(request, 'edit_case_user.html', {'case': case,'users':users,'projects':projects})


'''测试执行-管理员'''
def test_exe_admin(request):
    projects = getProjects(request)
    users = getUsers(request)
    products = getProducts(request)
    return render(request, 'test_exe_admin.html', {'projects': projects, 'users': users, 'products': products})



def testExeInProj_admin(request):
    project_id=request.GET.get("project_id")
    exe_cases=models.t_projcases.objects.filter(proj_no_id=project_id)
    users=getUsers(request)
    cases=getCases(request)
    return render(request,'testExeInProj_admin.html',{'exe_cases':exe_cases,'users':users,'cases':cases,'project_id':project_id})


'''删除用例，从projcases表里和t_cases表删除'''
def del_case_admin(request):
    id = request.GET.get("id")
    project_id=request.GET.get("project_id")
    # models.t_users.objects.filter(id=id).update(status=0)
    models.t_projcases.objects.filter(case_no_id=id).delete()
    models.t_cases.objects.filter(id=id).delete()
    context = {
        'context': u"离职状态设置成功！"
    }
    return HttpResponseRedirect("/testExeInProj_admin/?project_id="+project_id)


'''进入具体用例，标记执行状态'''
def exeShowCase_admin(request):
    case_id=request.GET.get("case_id")
    project_id=request.GET.get("project_id")
    case=models.t_cases.objects.filter(id=case_id).first()
    case_exe=models.t_projcases.objects.filter(case_no_id=case_id).first()
    if request.POST:
        # id=request.POST.get("caseId")
        exe_status=request.POST.get("status")
        remark=request.POST.get("remark")
        models.t_projcases.objects.filter(case_no_id=case_id).update(status=exe_status,remark=remark)
        message="修改成功"
        print message
        return HttpResponseRedirect("/testExeInProj_admin/?project_id="+project_id)
    return render(request,'exeShowCase_admin.html',{'case':case,'project_id':project_id,'case_exe':case_exe})










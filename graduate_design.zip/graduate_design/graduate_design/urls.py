"""graduate_design URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url
from django.contrib import admin
from myapp import views
from graduate_design import settings

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^hello$', views.hello),
    url(r'^login$', views.user_login),
    url(r'^404$', views.page404),
    url(r'^505$', views.page505),
    url(r'^barcharts$',views.barcharts),
    url(r'^buttons$',views.buttons),
    url(r'^calender$',views.calender),
    url(r'^datatables_user$',views.datatables_user),
    url(r'^datatables_admin$', views.datatables_admin),
    url(r'^cases_management_admin$',views.cases_management_admin),
    url(r'^cases_management_user$', views.cases_management_user),
    # url(r'^test_exe$',views.test_exe),
    url(r'^employee$',views.employee),
    url(r'^project_management_admin$', views.project_management_admin),
    url(r'^project_management_user$', views.project_management_user),
    url(r'^bug_management$', views.bug_management),
    url(r'^register$', views.register),
    url(r'^reset$', views.reset),
    url(r'^del_employee/$', views.del_employee),
    # url(r'^employee_editor/$', views.getin_employee_editor),
    url(r'^employee_change/$', views.employee_change),
    url(r'^close_project_admin/$', views.close_project_admin),
    url(r'^close_project_user/$', views.close_project_user),
    url(r'^start_project_admin/$', views.start_project_admin),
    url(r'^start_project_user/$', views.start_project_user),
    url(r'^new_project_admin$', views.new_project_admin),
    url(r'^new_project_user$', views.new_project_user),
    url(r'^new_case_admin$', views.new_case_admin),
    url(r'^new_case_user$', views.new_case_user),
    url(r'^edit_case_admin/$', views.edit_case_admin),
    url(r'^edit_case_user/$', views.edit_case_user),
    url(r'^test_exe_admin$', views.test_exe_admin),
    url(r'^testExeInProj_admin/$', views.testExeInProj_admin),
    url(r'^del_case_admin/$', views.del_case_admin),
    url(r'^caseDeletion_admin/$', views.caseDeletion_admin),
    url(r'^caseDeletion_user/$', views.caseDeletion_user),
    url(r'^exeShowCase_admin/$', views.exeShowCase_admin),

    #url(r'^static/(?P<path>.*)$','django.views.static.serve',{'document_root': settings.STATIC_URL}),
]
